Antes de empezar:

* Crea una BD vacía llamada `tareas` mediante MySQL/phpMyAdmin. Importa el fichero `tareas.sql`.
* Ejecuta `npm install` para reconstruir la carpeta `node_modules` con las dependencias del proyecto (en particular, al librería `mysql`).
* Modifica el fichero `config.js` con los datos de acceso a tu SGBD.